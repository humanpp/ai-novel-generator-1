# AI 网文小说生成软件 — 产品架构文档 v2.0

> 版本：v2.0  
> 日期：2026-04-27  
> 作者：产品架构师  
> 目标用户：网文作者（辅助创作工具）

---

## 一、产品概述

### 1.1 产品定位
面向网文作者的 AI 辅助创作工具，支持长篇小说与短篇小说的全流程创作，提供两种可切换的工作流模式，覆盖从灵感到大纲、细纲、角色、正文的完整链路。支持导入已有小说，由 AI 反推大纲、角色与细纲。

### 1.2 核心能力
- 双工作流模式（线性流程 A / 事件驱动流程 B）
- 支持长篇小说、短篇小说两种格式
- 导入已有小说 → AI 反推大纲 / 细纲 / 角色
- 全环节可手动编辑、重新生成
- 可切换模型，支持 OpenAI-compatible 外部模型（vLLM / Ollama / LM Studio 等）
- 大纲 / 章节历史版本管理，支持回溯
- 多格式导出（Word / TXT / EPUB）
- 写作统计（字数、时长、完成度）
- AI 生成角色关系脑图，支持交互式操作（拖拽 / 缩放 / 点击编辑）

---

## 二、技术栈

### 2.1 前端
| 技术 | 用途 |
|------|------|
| HTML5 + CSS3 | 页面结构与样式 |
| JavaScript (ES6+) | 交互逻辑 |
| Bootstrap 5 | UI 组件与响应式布局 |
| Axios | HTTP 请求（对接后端 API） |
| ECharts | 角色关系脑图（支持拖拽、缩放、点击编辑） |

### 2.2 后端
| 技术 | 用途 |
|------|------|
| Python 3.12 | 后端主语言 |
| Flask | Web 框架，提供 RESTful API |
| Flask-CORS | 跨域支持 |
| SQLite | 数据存储 |
| SQLAlchemy | ORM 层 |
| python-docx | 导出 Word，txt |

### 2.3 AI 模型层
| 类型 | 说明 |
|------|------|
| 内置模型 | 默认接入的 LLM |
| 外部模型（OpenAI-compatible） | 支持 vLLM、Ollama、LM Studio 等，用户配置 base_url + api_key + model_name 即可接入 |
| 模型参数 | temperature、max_tokens、top_p 等可调节 |

---

## 三、系统架构

```
┌──────────────────────────────────────────────────────────────┐
│                       前端（Browser）                        │
│  ┌──────────┐  ┌──────────┐  ┌──────────────────────────┐ │
│  │ 对话界面  │  │ 编辑界面  │  │  角色脑图（可交互）        │ │
│  └────┬─────┘  └────┬─────┘  └──────────┬───────────────┘ │
│       │              │                     │                  │
│       └──────────────┴─────────────────────┘                  │
│                         │ Axios REST API                      │
└─────────────────────────┼─────────────────────────────────────┘
                         │
┌─────────────────────────┼─────────────────────────────────────┐
│                         ▼                                     │
│                  ┌──────────┐                                 │
│                  │  Flask   │  后端服务                       │
│                  │  App     │                                 │
│                  └────┬─────┘                                 │
│                       │                                       │
│            ┌──────────┼──────────┐                            │
│            ▼          ▼          ▼                            │
│      ┌─────┐  ┌────────┐  ┌──────────┐                     │
│      │ API │  │ 业务逻辑 │  │  模型管理 │                     │
│      │路由 │  │ 层       │  │  模块     │                     │
│      └──┬──┘  └────┬───┘  └────┬─────┘                     │
│         │           │            │                            │
│         ▼           ▼            ▼                            │
│   ┌──────────────────────────────────┐                        │
│   │        数据持久层                 │                        │
│   │ (小说/大纲/细纲/章节/角色/        │                        │
│   │  版本记录/写作统计/导入记录)      │                        │
│   └──────────────────────────────────┘                        │
│                       │                                       │
│                 ┌─────▼──────────┐                           │
│                 │  LLM 模型层     │                           │
│                 │ (内置+OpenAI兼容)│                           │
│                 └────────────────┘                           │
└──────────────────────────────────────────────────────────────┘
```

---

## 四、核心功能模块

### 4.1 项目管理
- 创建 / 打开 / 删除小说项目
- 选择作品格式：**长篇小说** / **短篇小说**
- 项目基本信息（标题、类型、简介、创建时间、格式）

### 4.2 小说导入与反推（新增）
- 支持导入 TXT / Word 格式的已有小说（长篇 / 短篇均可）
- AI 自动反推：
  - 故事大纲（背景、主线、结局）
  - 章节细纲 / 事件细纲（根据原文结构）
  - 角色列表与角色关系
- 反推结果可编辑、重新生成

### 4.3 对话式大纲生成
- 多轮对话交互，逐步完善大纲
- 支持对生成结果进行「采纳 / 修改 / 重新生成」
- 大纲包含：故事背景、主线剧情、分卷结构、关键转折点

### 4.4 工作流 A：线性流程（章节细纲模式）
```
大纲 → 章节细纲 → 角色逻辑链 → 章节正文
```
- 用户设定：总章节数、每章目标字数（自动计算总字数）
- 系统生成：每章的情节要点、出场角色、关键事件
- 自动推导角色逻辑链（每个角色在各章节的行为动机与变化）

### 4.5 工作流 B：事件驱动流程（事件链模式）
```
大纲 → 事件链 → 角色逻辑链 → 章节正文
```
- 事件细纲：以关键事件为核心，强调因果链条
- 角色逻辑链：根据事件链推导每个角色的行为动机、成长轨迹、关系变化
- 章节映射：将事件链映射到具体章节（支持多事件合并为一章）

### 4.6 角色管理
- 自动抽取：根据大纲 / 细纲 / 导入文本自动识别小说角色
- 角色信息：姓名、性别、性格、背景、目标、关系网
- **角色关系脑图**：
  - 由 AI 自动生成初始脑图
  - 支持交互式操作：**拖拽**调整节点位置、**缩放**查看细节、**点击**编辑角色信息与关系

### 4.7 章节内容生成
- 输入：大纲 + 细纲 + 角色逻辑链
- 输出：完整章节正文
- 支持：单章生成 / 批量生成 / 重新生成 / 手动编辑

### 4.8 版本管理（新增）
- 大纲版本管理：每次修改自动保存版本，支持回溯到任意历史版本
- 章节版本管理：每次生成 / 编辑后自动保存版本，支持对比与回溯
- 版本列表展示，支持「预览 / 回滚 / 删除」

### 4.9 导出功能（新增）
- 支持导出格式：**Word (.docx)** / **纯文本 (.txt)** / **EPUB (.epub)**
- 导出范围：全本导出 / 指定章节导出
- 导出选项：是否包含大纲、是否包含角色介绍

### 4.10 写作统计（新增）
- 字数统计：总字数、已完成字数、剩余字数
- 写作时长：累计写作时长、本月/本周写作时长
- 完成度：按章节计算完成百分比，可视化展示进度条

### 4.11 模型管理
- 模型列表查看（内置 + 自定义 OpenAI-compatible 模型）
- 添加外部模型（填写 base_url、api_key、model_name，适配 vLLM / Ollama / LM Studio 等）
- 模型切换（全局默认 / 按任务类型指定）
- 模型参数调节（temperature、max_tokens 等）

---

## 五、工作流程详述

### 5.1 工作流 A：线性流程（章节细纲模式）

```
[开始]
   │
   ▼
[选择格式] ←── 长篇 / 短篇
   │
   ├───（可选）导入已有小说 → AI 反推大纲/细纲/角色
   │
   ▼
[对话生成大纲] ←── 用户多轮对话，AI 生成故事大纲
   │
   ▼
[确认大纲] ←── 用户可修改 / 重新生成（自动保存版本）
   │
   ▼
[设定章节参数] ←── 章节数、每章目标字数（自动计算总字数）
   │
   ▼
[生成章节细纲] ←── 每章：情节、出场角色、关键事件
   │
   ▼
[用户调整细纲] ←── 编辑 / 重新生成某章细纲
   │
   ▼
[生成角色逻辑链] ←── 根据大纲+章节细纲，推导每个角色的行为动机与变化轨迹
   │
   ▼
[AI 生成角色脑图] ←── 自动生成角色关系脑图
   │
   ▼
[用户调整脑图] ←── 拖拽/缩放/点击编辑角色关系
   │
   ▼
[生成章节正文] ←── 逐章生成，基于大纲+细纲+角色逻辑链
   │
   ▼
[用户编辑/重生成] ←── 对不满意章节进行调整（自动保存版本）
   │
   ▼
[写作统计更新] ←── 实时更新字数、完成度
   │
   ▼
[导出作品] ←── Word / TXT / EPUB
   │
   ▼
[完成作品]
```

### 5.2 工作流 B：事件驱动流程（事件链模式）

```
[开始]
   │
   ▼
[选择格式] ←── 长篇 / 短篇
   │
   ├───（可选）导入已有小说 → AI 反推大纲/事件链/角色
   │
   ▼
[对话生成大纲] ←── 用户多轮对话，AI 生成故事大纲
   │
   ▼
[确认大纲] ←── 用户可修改 / 重新生成（自动保存版本）
   │
   ▼
[生成事件链] ←── 环环相扣的事件链（强调因果关系）
   │
   ▼
[用户调整事件] ←── 编辑事件链、调整事件顺序
   │
   ▼
[生成角色逻辑链] ←── 从事件链推导角色动机、变化、关系
   │
   ▼
[AI 生成角色脑图] ←── 自动生成角色关系脑图
   │
   ▼
[用户调整脑图] ←── 拖拽/缩放/点击编辑角色关系
   │
   ▼
[映射生成章节] ←── 将事件链映射到具体章节（支持多事件合一章）
   │
   ▼
[生成章节正文] ←── 逐章生成
   │
   ▼
[用户编辑/重生成] ←── 对不满意章节进行调整（自动保存版本）
   │
   ▼
[写作统计更新] ←── 实时更新字数、完成度
   │
   ▼
[导出作品] ←── Word / TXT / EPUB
   │
   ▼
[完成作品]
```

---

## 六、数据库设计（核心表）

### 6.1 novels（小说项目表）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| title | VARCHAR | 小说标题 |
| genre | VARCHAR | 类型（玄幻/都市/科幻等） |
| format | VARCHAR | 格式：long（长篇）/ short（短篇） |
| summary | TEXT | 项目简介 |
| created_at | DATETIME | 创建时间 |
| updated_at | DATETIME | 更新时间 |

### 6.2 outlines（大纲表）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| novel_id | INT FK | 关联小说 |
| content | TEXT | 大纲内容（JSON 或纯文本） |
| mode | VARCHAR | 模式：chapter（流程A）/ event（流程B） |
| version | INT | 当前版本号 |

### 6.3 outline_versions（大纲版本表·新增）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| outline_id | INT FK | 关联大纲 |
| version | INT | 版本号 |
| content | TEXT | 该版本的大纲内容 |
| created_at | DATETIME | 版本创建时间 |

### 6.4 chapter_outlines（章节细纲表）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| novel_id | INT FK | 关联小说 |
| chapter_no | INT | 章节序号 |
| word_count | INT | 目标字数 |
| content | TEXT | 细纲内容 |
| events | TEXT | 关联事件（JSON） |

### 6.5 event_outlines（事件细纲表）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| novel_id | INT FK | 关联小说 |
| event_no | INT | 事件序号 |
| title | VARCHAR | 事件标题 |
| description | TEXT | 事件描述 |
| cause | TEXT | 前因 |
| effect | TEXT | 后果 |
| related_characters | TEXT | 关联角色（JSON） |

### 6.6 character_logic_chains（角色逻辑链表·新增）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| novel_id | INT FK | 关联小说 |
| character_id | INT FK | 关联角色 |
| chapter_no | INT | 章节序号（或事件序号） |
| motivation | TEXT | 该章节/事件中的行为动机 |
| change | TEXT | 该章节/事件中的角色变化 |
| content | TEXT | 完整逻辑链描述 |

### 6.7 characters（角色表）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| novel_id | INT FK | 关联小说 |
| name | VARCHAR | 角色名 |
| gender | VARCHAR | 性别 |
| personality | TEXT | 性格描述 |
| background | TEXT | 背景故事 |
| goal | TEXT | 目标动机 |
| relations | TEXT | 角色关系（JSON，用于脑图） |

### 6.8 chapters（章节正文表）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| novel_id | INT FK | 关联小说 |
| chapter_no | INT | 章节序号 |
| title | VARCHAR | 章节标题 |
| content | TEXT | 正文内容 |
| word_count | INT | 实际字数 |
| generated_at | DATETIME | 生成时间 |

### 6.9 chapter_versions（章节版本表·新增）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| chapter_id | INT FK | 关联章节 |
| version | INT | 版本号 |
| content | TEXT | 该版本的章节内容 |
| word_count | INT | 该版本的字数 |
| created_at | DATETIME | 版本创建时间 |

### 6.10 writing_stats（写作统计表·新增）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| novel_id | INT FK | 关联小说 |
| total_words | INT | 总字数 |
| completed_words | INT | 已完成字数 |
| completion_rate | FLOAT | 完成度（百分比） |
| writing_duration | INT | 累计写作时长（秒） |
| last_writing_time | DATETIME | 最近写作时间 |

### 6.11 import_records（导入记录表·新增）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| novel_id | INT FK | 关联小说 |
| file_name | VARCHAR | 导入文件名 |
| file_path | VARCHAR | 文件存储路径 |
| import_time | DATETIME | 导入时间 |
| status | VARCHAR | 状态：pending / processing / done / failed |

### 6.12 model_configs（模型配置表）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| name | VARCHAR | 配置名称 |
| provider | VARCHAR | 提供商（openai/anthropic/custom等） |
| base_url | VARCHAR | API 地址（OpenAI-compatible） |
| api_key | VARCHAR | API 密钥（加密存储） |
| model_name | VARCHAR | 模型名称 |
| temperature | FLOAT | 温度参数 |
| max_tokens | INT | 最大 token |
| is_default | BOOLEAN | 是否默认模型 |
| is_builtin | BOOLEAN | 是否内置模型 |

---

## 七、后端 API 设计（Flask）

### 7.1 项目接口
| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /api/novels | 获取项目列表 |
| POST | /api/novels | 创建新项目（指定格式：长篇/短篇） |
| GET | /api/novels/<id> | 获取项目详情 |
| PUT | /api/novels/<id> | 更新项目 |
| DELETE | /api/novels/<id> | 删除项目 |

### 7.2 小说导入接口（新增）
| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /api/novels/import | 上传小说文件（TXT/Word） |
| POST | /api/novels/<id>/reverse-outline | AI 反推大纲 |
| POST | /api/novels/<id>/reverse-detail | AI 反推细纲 |
| POST | /api/novels/<id>/reverse-characters | AI 反推角色 |
| GET | /api/import-records | 获取导入记录列表 |

### 7.3 大纲接口
| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /api/novels/<id>/outline/generate | AI 对话生成大纲 |
| GET | /api/novels/<id>/outline | 获取大纲 |
| PUT | /api/novels/<id>/outline | 更新大纲（自动保存版本） |
| POST | /api/novels/<id>/outline/chat | 大纲对话迭代 |
| GET | /api/novels/<id>/outline/versions | 获取大纲版本列表 |
| POST | /api/novels/<id>/outline/rollback | 回滚到指定大纲版本 |

### 7.4 章节细纲接口（流程A）
| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /api/novels/<id>/chapter-outlines/generate | 生成章节细纲 |
| GET | /api/novels/<id>/chapter-outlines | 获取章节细纲列表 |
| PUT | /api/novels/<id>/chapter-outlines/<ch_no> | 更新某章细纲 |
| POST | /api/novels/<id>/chapter-outlines/<ch_no>/regenerate | 重新生成某章细纲 |

### 7.5 事件细纲接口（流程B）
| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /api/novels/<id>/event-outlines/generate | 生成事件细纲 |
| GET | /api/novels/<id>/event-outlines | 获取事件细纲列表 |
| PUT | /api/novels/<id>/event-outlines/<ev_no> | 更新某事件 |
| POST | /api/novels/<id>/character-logic/generate | 生成角色逻辑链 |

### 7.6 角色接口
| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /api/novels/<id>/characters/extract | 从大纲/细纲抽取角色 |
| GET | /api/novels/<id>/characters | 获取角色列表 |
| PUT | /api/novels/<id>/characters/<ch_id> | 更新角色信息 |
| GET | /api/novels/<id>/characters/mindmap | 获取角色关系数据（脑图用） |
| PUT | /api/novels/<id>/characters/mindmap | 更新角色关系数据（脑图编辑后保存） |

### 7.7 章节正文接口
| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /api/novels/<id>/chapters/generate | 生成章节正文 |
| GET | /api/novels/<id>/chapters | 获取章节列表 |
| GET | /api/novels/<id>/chapters/<ch_no> | 获取某章内容 |
| PUT | /api/novels/<id>/chapters/<ch_no> | 更新某章内容（自动保存版本） |
| POST | /api/novels/<id>/chapters/<ch_no>/regenerate | 重新生成某章 |
| GET | /api/novels/<id>/chapters/<ch_no>/versions | 获取章节版本列表 |
| POST | /api/novels/<id>/chapters/<ch_no>/rollback | 回滚到指定章节版本 |

### 7.8 导出接口（新增）
| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /api/novels/<id>/export/docx | 导出为 Word |
| POST | /api/novels/<id>/export/txt | 导出为 TXT |
| POST | /api/novels/<id>/export/epub | 导出为 EPUB |

### 7.9 写作统计接口（新增）
| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /api/novels/<id>/stats | 获取写作统计 |
| PUT | /api/novels/<id>/stats/writing-time | 更新写作时长（开始/结束写作时调用） |

### 7.10 模型配置接口
| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /api/models | 获取可用模型列表 |
| POST | /api/models | 添加自定义模型（OpenAI-compatible） |
| PUT | /api/models/<id> | 更新模型配置 |
| DELETE | /api/models/<id> | 删除自定义模型 |
| POST | /api/models/switch | 切换当前默认模型 |

---

## 八、前端页面设计

### 8.1 页面结构
```
┌────────────────────────────────────────────────────────────┐
│  顶部导航栏：Logo | 项目列表 | 模型设置 | 帮助   │
├────────────────────────────────────────────────────────────┤
│  ┌──────────┐ ┌──────────────────────────────────────────┐  │
│  │ 侧边栏    │ │        主内容区                            │  │
│  │          │ │                                          │  │
│  │ 项目信息  │ │  工作区（根据当前步骤动态切换）             │  │
│  │          │ │  ┌────────┐  ┌──────────────┐          │  │
│  │ 大纲管理  │ │  │ 对话   │  │  大纲/细纲    │          │  │
│  │          │ │  │ 界面   │  │  编辑器        │          │  │
│  │ 细纲管理  │ │  └────────┘  └──────────────┘          │  │
│  │  ┌────┐ │ │                                          │  │
│  │  │角色│ │ │  ┌──────────────────────────────────┐    │  │
│  │  │脑图│ │ │  │  角色关系脑图（可拖拽/缩放/点击） │    │  │
│  │  │展示│ │ │  └──────────────────────────────────┘    │  │
│  │  └────┘ │ │                                          │  │
│  │          │ │  ┌──────────────────────────────────┐    │  │
│  │ 章节管理  │ │  │  章节正文编辑与预览                   │    │  │
│  │          │ │  └──────────────────────────────────┘    │  │
│  │ 写作统计  │ │                                          │  │
│  │ 模型设置  │ │  ┌──────────────────────────────────┐    │  │
│  │          │ │  │  版本管理面板（大纲/章节）           │    │  │
│  └──────────┘ └──────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────────┤
│  底部状态栏：写作统计（字数/完成度/时长）                    │
└────────────────────────────────────────────────────────────┘
```

### 8.2 关键组件说明
- **对话界面**：仿聊天 UI，支持多轮对话，显示 AI 回复与用户操作按钮（采纳/修改/重新生成）
- **大纲/细纲编辑器**：基于 textarea 或富文本编辑器，支持实时保存，侧边显示版本历史
- **角色关系脑图**：
  - 使用 ECharts / jsMind 实现
  - AI 自动生成初始布局
  - 支持**拖拽**移动节点、**滚轮缩放**、**点击节点**编辑角色信息与关系
- **章节预览**：分屏显示（编辑区 + 预览区），支持 Markdown 渲染
- **版本管理面板**：大纲/章节分别显示版本列表，支持预览、回滚、删除
- **写作统计栏**：实时显示总字数、已完成字数、完成度进度条、今日写作时长
- **模型设置面板**：表单式配置，支持测试连接，明确标注支持 vLLM / Ollama / LM Studio 等 OpenAI-compatible 服务
- **导入功能**：支持拖拽上传 TXT / Word 文件，上传后触发 AI 反推流程

---

## 九、模型接入设计

### 9.1 模型调用抽象层
```python
class LLMClient:
    """LLM 调用统一接口，支持所有 OpenAI-compatible 服务"""
    def __init__(self, config: ModelConfig):
        self.config = config
        self.client = OpenAI(
            base_url=config.base_url,
            api_key=config.api_key
        )

    def chat(self, messages: list, **kwargs) -> str:
        """对话式调用（用于大纲生成、对话迭代）"""
        response = self.client.chat.completions.create(
            model=self.config.model_name,
            messages=messages,
            temperature=kwargs.get("temperature", self.config.temperature),
            max_tokens=kwargs.get("max_tokens", self.config.max_tokens),
        )
        return response.choices[0].message.content

    def complete(self, prompt: str, **kwargs) -> str:
        """补全式调用（用于细纲、章节生成）"""
        response = self.client.chat.completions.create(
            model=self.config.model_name,
            messages=[{"role": "user", "content": prompt}],
            temperature=kwargs.get("temperature", self.config.temperature),
            max_tokens=kwargs.get("max_tokens", self.config.max_tokens),
        )
        return response.choices[0].message.content
```

### 9.2 外部模型配置示例（OpenAI-compatible）
```json
// vLLM / Ollama / LM Studio 均适用
{
  "name": "本地 Qwen3-32B（vLLM）",
  "provider": "custom",
  "base_url": "http://localhost:8000/v1",
  "api_key": "EMPTY",
  "model_name": "qwen/qwen3-32b",
  "temperature": 0.7,
  "max_tokens": 4096
}
```

---

## 十、关键实现要点

### 10.1 Prompt 工程
- 大纲生成：明确故事类型、篇幅（长篇/短篇）、风格要求
- 细纲生成：强调章节间的连贯性与节奏控制
- 事件链生成：突出因果逻辑，避免前后矛盾
- 角色逻辑链生成：要求按章节/事件输出每个角色的行为动机与变化
- 角色抽取：结构化输出（JSON），便于解析和存储
- 章节生成：注入大纲+细纲+角色逻辑链作为上下文
- **导入反推**：针对导入的文本，要求 AI 按原文结构逆向推导大纲与细纲

### 10.2 上下文管理
- 长篇小说上下文可能超出模型窗口，需采用：
  - 摘要压缩（对已完成章节生成摘要）
  - 滑动窗口（保留最近 N 章上下文）
  - 向量检索（将大纲/细纲向量化，按需检索）

### 10.3 版本管理实现
- 大纲/章节每次更新时，先将当前内容存入版本表，再更新主表
- 版本列表按时间倒序展示，支持差异对比（可选）
- 回滚操作：将指定版本的内容覆盖到主表

### 10.4 写作统计实现
- 前端在用户进入编辑状态时，调用「开始写作」接口，后端记录开始时间
- 用户离开编辑区或关闭页面时，调用「结束写作」接口，后端计算时长并累加
- 字数统计：每次章节保存时，重新统计该章节字数，更新总字数

### 10.5 导出实现
- **Word 导出**：使用 python-docx，按章节生成带格式的 Word 文档
- **TXT 导出**：纯文本拼接，按章节分段
- **EPUB 导出**：使用 ebooklib，生成标准 EPUB 3.0 格式，支持封面、目录、章节跳转

### 10.6 错误处理
- API 调用失败：重试机制（指数退避）
- 内容审核：过滤敏感内容
- 用户中断：支持取消正在生成的任务
- 导入文件过大：分块处理，避免内存溢出

---

## 十一、短篇小说格式说明（新增）

短篇格式与长篇格式的区别：
| 维度 | 长篇 | 短篇 |
|------|------|------|
| 章节数 | 几十到几百章 | 1~10 章 |
| 细纲模式 | 支持流程A（章节细纲）/ 流程B（事件链） | 推荐使用流程B（事件链更紧凑） |
| 角色数量 | 较多（5~20+） | 较少（1~5） |
| 导出 | 支持全本导出 | 支持单篇导出 |
| 写作统计 | 按章节统计 | 按全篇统计 |

短篇创作流程：
```
新建项目 → 选择「短篇」→ 对话生成大纲 → 生成事件链 → 生成角色逻辑链 → 生成单章/少数章节 → 编辑 → 导出
```

---

## 十二、后续扩展方向

- [ ] 多语言支持（国际化）
- [ ] 协作编辑（多用户同时编辑同一项目）
- [ ] 灵感库（素材收集、情节卡片）
- [ ] 移动端适配
- [ ] AI 辅助润色（扩写 / 缩写 / 风格转换）
- [ ] 章节评论与批注
- [ ] 与网文平台对接（一键发布）

---

*文档结束 · v2.0*
