# AI网文小说生成软件 — 优化后数据库表设计

> 优化说明：
> 1. 小说项目表（novels）新增`workflow_mode`字段，项目创建时必填，确认工作流模式（流程A/流程B）
> 2. 章节表（chapters）新增`chapter_outline_id`字段，关联章节细纲表（流程A使用）
> 3. 新增`chapter_event_mapping`中间表，关联章节与事件细纲（流程B使用，支持多事件映射到一个章节）
> 4. 新增`chapter_characters`中间表，直接关联章节与角色，明确每个章节出场角色
> 5. 调整相关外键关联，确保数据一致性

---

## 1. novels（小说项目表·优化后）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| title | VARCHAR | 小说标题 |
| genre | VARCHAR | 类型（玄幻/都市/科幻等） |
| format | VARCHAR | 格式：long（长篇）/ short（短篇） |
| workflow_mode | VARCHAR NOT NULL | 工作流模式：chapter（流程A，线性章节细纲）/ event（流程B，事件驱动），项目创建时必填 |
| summary | TEXT | 项目简介 |
| created_at | DATETIME | 创建时间 |
| updated_at | DATETIME | 更新时间 |

---

## 2. outlines（大纲表·优化后）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| novel_id | INT FK | 关联小说（novels.id） |
| content | TEXT | 大纲内容（JSON 或纯文本） |
| version | INT | 当前版本号 |
| （注：原mode字段已移除，工作流模式统一由novels.workflow_mode管理） |

---

## 3. outline_versions（大纲版本表）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| outline_id | INT FK | 关联大纲（outlines.id） |
| version | INT | 版本号 |
| content | TEXT | 该版本的大纲内容 |
| created_at | DATETIME | 版本创建时间 |

---

## 4. chapter_outlines（章节细纲表·流程A）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| novel_id | INT FK | 关联小说（novels.id） |
| chapter_no | INT | 章节序号 |
| word_count | INT | 目标字数 |
| content | TEXT | 细纲内容 |
| events | TEXT | 关联事件（JSON，可选） |

---

## 5. event_outlines（事件细纲表·流程B）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| novel_id | INT FK | 关联小说（novels.id） |
| event_no | INT | 事件序号 |
| title | VARCHAR | 事件标题 |
| description | TEXT | 事件描述 |
| cause | TEXT | 前因 |
| effect | TEXT | 后果 |
| related_characters | TEXT | 关联角色（JSON） |

---

## 6. chapters（章节正文表·优化后）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| novel_id | INT FK | 关联小说（novels.id） |
| chapter_no | INT | 章节序号 |
| title | VARCHAR | 章节标题 |
| content | TEXT | 正文内容 |
| word_count | INT | 实际字数 |
| generated_at | DATETIME | 生成时间 |
| chapter_outline_id | INT FK NULL | 关联章节细纲（chapter_outlines.id），流程A使用，流程B下为NULL |

---

## 7. chapter_event_mapping（章节事件关联表·新增）
> 用于流程B：将事件细纲映射到章节（支持多事件合并为一章）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| chapter_id | INT FK | 关联章节（chapters.id） |
| event_id | INT FK | 关联事件细纲（event_outlines.id） |
| sort_order | INT | 章节在事件中的排序（多事件时生效） |

---

## 8. characters（角色表）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| novel_id | INT FK | 关联小说（novels.id） |
| name | VARCHAR | 角色名 |
| gender | VARCHAR | 性别 |
| personality | TEXT | 性格描述 |
| background | TEXT | 背景故事 |
| goal | TEXT | 目标动机 |
| relations | TEXT | 角色关系（JSON，用于脑图） |

---

## 9. chapter_characters（章节角色关联表·新增）
> 直接关联章节与出场角色，明确每个章节的角色参与情况
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| chapter_id | INT FK | 关联章节（chapters.id） |
| character_id | INT FK | 关联角色（characters.id） |
| role_desc | TEXT | 角色在该章节的作用描述（可选） |

---

## 10. character_logic_chains（角色逻辑链表）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| novel_id | INT FK | 关联小说（novels.id） |
| character_id | INT FK | 关联角色（characters.id） |
| chapter_no | INT | 章节序号（或事件序号） |
| motivation | TEXT | 该章节/事件中的行为动机 |
| change | TEXT | 该章节/事件中的角色变化 |
| content | TEXT | 完整逻辑链描述 |

---

## 11. chapter_versions（章节版本表）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| chapter_id | INT FK | 关联章节（chapters.id） |
| version | INT | 版本号 |
| content | TEXT | 该版本的章节内容 |
| word_count | INT | 该版本的字数 |
| created_at | DATETIME | 版本创建时间 |

---

## 12. writing_stats（写作统计表）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| novel_id | INT FK | 关联小说（novels.id） |
| total_words | INT | 总字数 |
| completed_words | INT | 已完成字数 |
| completion_rate | FLOAT | 完成度（百分比） |
| writing_duration | INT | 累计写作时长（秒） |
| last_writing_time | DATETIME | 最近写作时间 |

---

## 13. import_records（导入记录表）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| novel_id | INT FK | 关联小说（novels.id） |
| file_name | VARCHAR | 导入文件名 |
| file_path | VARCHAR | 文件存储路径 |
| import_time | DATETIME | 导入时间 |
| status | VARCHAR | 状态：pending / processing / done / failed |

---

## 14. model_configs（模型配置表）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INT PK | 主键 |
| name | VARCHAR | 配置名称 |
| provider | VARCHAR | 提供商（openai/anthropic/custom等） |
| base_url | VARCHAR | API 地址（OpenAI-compatible） |
| api_key | VARCHAR | API 密钥（加密存储） |
| model_name | VARCHAR | 模型名称 |
| temperature | FLOAT | 温度参数 |
| max_tokens | INT | 最大 token |
| is_default | BOOLEAN | 是否默认模型 |
| is_builtin | BOOLEAN | 是否内置模型 |

---

## 关联关系统览
1. 项目级：`novels.workflow_mode` 决定工作流模式（流程A/流程B）
2. 流程A（线性章节细纲）：
   - `chapters.chapter_outline_id` → `chapter_outlines.id`
   - `chapter_outlines.novel_id` → `novels.id`
3. 流程B（事件驱动）：
   - `chapter_event_mapping.chapter_id` → `chapters.id`
   - `chapter_event_mapping.event_id` → `event_outlines.id`
   - `event_outlines.novel_id` → `novels.id`
4. 角色关联：
   - `chapter_characters.chapter_id` → `chapters.id`
   - `chapter_characters.character_id` → `characters.id`
   - `character_logic_chains.character_id` → `characters.id`