- # AI网文小说生成软件 — 后端架构规划 v2.0（优化版）

  > 基于《AI 网文小说生成软件 — 产品架构文档 v2.0》及优化后的数据模型  
  > 提取日期：2026-04-28  
  > 更新日期：2026-04-29

  ---

  ## 一、后端技术栈

  | 技术        | 用途                       |
  | ----------- | -------------------------- |
  | Python 3.12 | 后端主语言                 |
  | Flask       | Web 框架，提供 RESTful API |
  | Flask-CORS  | 跨域支持                   |
  | SQLite      | 数据存储                   |
  | SQLAlchemy  | ORM 层                     |
  | python-docx | 导出 Word                  |
  | ebooklib    | 导出 EPUB                  |
  | openai      | 调用兼容接口的 LLM         |

  ---

  ## 二、系统架构

  ```
  ┌──────────────────────────────────────────────────────────────┐
  │                       前端（Browser）                        │
  │  ┌──────────┐  ┌──────────┐  ┌──────────────────────────┐ │
  │  │ 对话界面  │  │ 编辑界面  │  │  角色脑图（可交互）        │ │
  │  └────┬─────┘  └────┬─────┘  └──────────┬───────────────┘ │
  │       │              │                     │                  │
  │       └──────────────┴─────────────────────┘                  │
  │                         │ Axios REST API                      │
  └─────────────────────────┼─────────────────────────────────────┘
                           │
  ┌─────────────────────────┼─────────────────────────────────────┐
  │                         ▼                                     │
  │                  ┌──────────┐                                 │
  │                  │  Flask   │  后端服务                       │
  │                  │  App     │                                 │
  │                  └────┬─────┘                                 │
  │                       │                                       │
  │            ┌──────────┼──────────┐                            │
  │            ▼          ▼          ▼                            │
  │      ┌─────┐  ┌────────┐  ┌──────────┐                     │
  │      │ API │  │ 业务逻辑 │  │  模型管理 │                     │
  │      │路由 │  │ 层       │  │  模块     │                     │
  │      └──┬──┘  └────┬───┘  └────┬─────┘                     │
  │         │           │            │                            │
  │         ▼           ▼            ▼                            │
  │   ┌──────────────────────────────────┐                        │
  │   │        数据持久层                 │                        │
  │   │ (小说/大纲/细纲/章节/角色/        │                        │
  │   │  版本记录/写作统计/导入记录)      │                        │
  │   └──────────────────────────────────┘                        │
  │                       │                                       │
  │                 ┌─────▼──────────┐                           │
  │                 │  LLM 模型层     │                           │
  │                 │ (内置+OpenAI兼容)│                           │
  │                 └────────────────┘                           │
  └──────────────────────────────────────────────────────────────┘
  ```

  ---

  ## 三、后端 API 设计

  ### 3.1 项目接口

  | 方法   | 路径             | 说明                               |
  | ------ | ---------------- | ---------------------------------- |
  | GET    | /api/novels      | 获取项目列表                       |
  | POST   | /api/novels      | 创建新项目（必填格式与工作流模式） |
  | GET    | /api/novels/<id> | 获取项目详情                       |
  | PUT    | /api/novels/<id> | 更新项目                           |
  | DELETE | /api/novels/<id> | 删除项目                           |

  ### 3.2 小说导入接口

  | 方法 | 路径                                | 说明                     |
  | ---- | ----------------------------------- | ------------------------ |
  | POST | /api/novels/import                  | 上传小说文件（TXT/Word） |
  | POST | /api/novels/<id>/reverse-outline    | AI 反推大纲（支持异步）  |
  | POST | /api/novels/<id>/reverse-detail     | AI 反推细纲（支持异步）  |
  | POST | /api/novels/<id>/reverse-characters | AI 反推角色（支持异步）  |
  | GET  | /api/import-records                 | 获取导入记录列表         |
  | GET  | /api/import-records/<record_id>     | 获取单条导入记录详情     |

  ### 3.3 大纲接口

  | 方法 | 路径                                  | 说明                                         |
  | ---- | ------------------------------------- | -------------------------------------------- |
  | POST | /api/novels/<id>/outline/generate     | 开启 AI 对话生成大纲                         |
  | POST | /api/novels/<id>/outline/chat         | 大纲对话迭代                                 |
  | POST | /api/novels/<id>/outline/accept       | 采纳当前对话结果，写入正式大纲并自动保存版本 |
  | GET  | /api/novels/<id>/outline              | 获取大纲                                     |
  | PUT  | /api/novels/<id>/outline              | 直接更新大纲（自动保存版本）                 |
  | GET  | /api/novels/<id>/outline/versions     | 获取大纲版本列表                             |
  | POST | /api/novels/<id>/outline/rollback     | 回滚到指定大纲版本                           |
  | GET  | /api/novels/<id>/outline/chat-history | 获取大纲生成的多轮对话历史                   |

  ### 3.4 章节细纲接口（流程A）

  | 方法   | 路径                                                 | 说明                     |
  | ------ | ---------------------------------------------------- | ------------------------ |
  | POST   | /api/novels/<id>/chapter-outlines/generate           | 生成章节细纲（支持异步） |
  | GET    | /api/novels/<id>/chapter-outlines                    | 获取章节细纲列表         |
  | GET    | /api/novels/<id>/chapter-outlines/<ch_no>            | 获取某章细纲             |
  | PUT    | /api/novels/<id>/chapter-outlines/<ch_no>            | 更新某章细纲             |
  | DELETE | /api/novels/<id>/chapter-outlines/<ch_no>            | 删除某章细纲             |
  | POST   | /api/novels/<id>/chapter-outlines/<ch_no>/regenerate | 重新生成某章细纲         |

  ### 3.5 事件细纲接口（流程B）

  | 方法   | 路径                                               | 说明                                     |
  | ------ | -------------------------------------------------- | ---------------------------------------- |
  | POST   | /api/novels/<id>/event-outlines/generate           | 生成事件细纲（支持异步）                 |
  | GET    | /api/novels/<id>/event-outlines                    | 获取事件细纲列表                         |
  | GET    | /api/novels/<id>/event-outlines/<ev_no>            | 获取某个事件                             |
  | PUT    | /api/novels/<id>/event-outlines/<ev_no>            | 更新某个事件                             |
  | DELETE | /api/novels/<id>/event-outlines/<ev_no>            | 删除某个事件                             |
  | POST   | /api/novels/<id>/event-outlines/<ev_no>/regenerate | 重新生成某个事件                         |
  | PUT    | /api/novels/<id>/event-outlines/reorder            | 批量更新事件顺序（请求体传递事件ID数组） |

  ### 3.6 角色接口

  | 方法   | 路径                                  | 说明                               |
  | ------ | ------------------------------------- | ---------------------------------- |
  | POST   | /api/novels/<id>/characters/extract   | 从大纲/细纲抽取角色（支持异步）    |
  | GET    | /api/novels/<id>/characters           | 获取角色列表                       |
  | POST   | /api/novels/<id>/characters           | 手动创建角色                       |
  | GET    | /api/novels/<id>/characters/<char_id> | 获取单个角色详情                   |
  | PUT    | /api/novels/<id>/characters/<char_id> | 更新角色信息                       |
  | DELETE | /api/novels/<id>/characters/<char_id> | 删除角色                           |
  | GET    | /api/novels/<id>/characters/mindmap   | 获取角色关系数据（脑图用）         |
  | PUT    | /api/novels/<id>/characters/mindmap   | 更新角色关系数据（脑图编辑后保存） |

  ### 3.7 角色逻辑链接口（通用，流程A/流程B均适用）

  | 方法   | 路径                                        | 说明                                                     |
  | ------ | ------------------------------------------- | -------------------------------------------------------- |
  | POST   | /api/novels/<id>/character-logic/generate   | 生成角色逻辑链（根据工作流模式自动选择数据源，支持异步） |
  | GET    | /api/novels/<id>/character-logic            | 获取角色逻辑链列表                                       |
  | PUT    | /api/novels/<id>/character-logic/<logic_id> | 修改某条逻辑链（动机/变化）                              |
  | DELETE | /api/novels/<id>/character-logic/<logic_id> | 删除某条逻辑链                                           |

  ### 3.8 章节正文接口

  | 方法   | 路径                                         | 说明                                         |
  | ------ | -------------------------------------------- | -------------------------------------------- |
  | POST   | /api/novels/<id>/chapters/<ch_no>/generate   | 生成单章正文                                 |
  | POST   | /api/novels/<id>/chapters/generate-batch     | 批量生成章节（请求体指定章节序号列表，异步） |
  | GET    | /api/novels/<id>/chapters                    | 获取章节列表                                 |
  | GET    | /api/novels/<id>/chapters/<ch_no>            | 获取某章内容（含版本信息）                   |
  | PUT    | /api/novels/<id>/chapters/<ch_no>            | 更新某章内容（自动保存版本）                 |
  | DELETE | /api/novels/<id>/chapters/<ch_no>            | 删除某章                                     |
  | POST   | /api/novels/<id>/chapters/<ch_no>/regenerate | 重新生成某章                                 |
  | GET    | /api/novels/<id>/chapters/<ch_no>/versions   | 获取章节版本列表                             |
  | POST   | /api/novels/<id>/chapters/<ch_no>/rollback   | 回滚到指定章节版本                           |

  ### 3.9 章节角色关联接口

  | 方法 | 路径                                         | 说明                         |
  | ---- | -------------------------------------------- | ---------------------------- |
  | GET  | /api/novels/<id>/chapters/<ch_no>/characters | 获取该章节出场角色           |
  | PUT  | /api/novels/<id>/chapters/<ch_no>/characters | 更新该章节出场角色及作用描述 |

  ### 3.10 章节事件映射接口（流程B专用）

  | 方法 | 路径                                              | 说明                         |
  | ---- | ------------------------------------------------- | ---------------------------- |
  | GET  | /api/novels/<id>/chapters/<ch_no>/events          | 获取该章节关联的事件及排序   |
  | PUT  | /api/novels/<id>/chapters/<ch_no>/events          | 手动调整该章关联的事件及排序 |
  | POST | /api/novels/<id>/chapters/<ch_no>/events/auto-map | 重新自动映射该章的事件       |

  ### 3.11 导出接口

  | 方法 | 路径                         | 说明                    |
  | ---- | ---------------------------- | ----------------------- |
  | POST | /api/novels/<id>/export/docx | 导出为 Word（支持异步） |
  | POST | /api/novels/<id>/export/txt  | 导出为 TXT（支持异步）  |
  | POST | /api/novels/<id>/export/epub | 导出为 EPUB（支持异步） |

  ### 3.12 写作统计接口

  | 方法 | 路径                                 | 说明                             |
  | ---- | ------------------------------------ | -------------------------------- |
  | GET  | /api/novels/<id>/stats               | 获取写作统计                     |
  | POST | /api/novels/<id>/stats/start-writing | 开始写作计时（返回会话ID）       |
  | POST | /api/novels/<id>/stats/stop-writing  | 停止计时并累加时长（传入会话ID） |

  ### 3.13 模型配置接口

  | 方法   | 路径                        | 说明                                |
  | ------ | --------------------------- | ----------------------------------- |
  | GET    | /api/models                 | 获取可用模型列表（不返回完整密钥）  |
  | GET    | /api/models/current-default | 获取当前默认模型配置摘要            |
  | POST   | /api/models                 | 添加自定义模型（OpenAI-compatible） |
  | POST   | /api/models/test            | 测试模型连接（请求体携带配置）      |
  | PUT    | /api/models/<id>            | 更新模型配置                        |
  | DELETE | /api/models/<id>            | 删除自定义模型                      |
  | POST   | /api/models/switch          | 切换当前默认模型                    |

  ### 3.14 异步任务接口（通用）

  | 方法   | 路径                 | 说明                                                         |
  | ------ | -------------------- | ------------------------------------------------------------ |
  | GET    | /api/tasks/<task_id> | 查询异步任务状态（pending/running/done/failed）及结果/错误信息 |
  | DELETE | /api/tasks/<task_id> | 取消或清理已完成的任务（可选）                               |

  ### 3.15 版本对比接口（预留）

  | 方法 | 路径                                                      | 说明                       |
  | ---- | --------------------------------------------------------- | -------------------------- |
  | GET  | /api/novels/<id>/outline/versions/<v1>/diff/<v2>          | 获取两个大纲版本的文本差异 |
  | GET  | /api/novels/<id>/chapters/<ch_no>/versions/<v1>/diff/<v2> | 获取两个章节版本的文本差异 |

  ---

  ## 四、模型接入设计

  ### 4.1 模型调用抽象层

  ```python
  class LLMClient:
      """LLM 调用统一接口，支持所有 OpenAI-compatible 服务"""
      def __init__(self, config: ModelConfig):
          self.config = config
          self.client = OpenAI(
              base_url=config.base_url,
              api_key=config.api_key
          )
  
      def chat(self, messages: list, **kwargs) -> str:
          """对话式调用（用于大纲生成、对话迭代）"""
          response = self.client.chat.completions.create(
              model=self.config.model_name,
              messages=messages,
              temperature=kwargs.get("temperature", self.config.temperature),
              max_tokens=kwargs.get("max_tokens", self.config.max_tokens),
          )
          return response.choices[0].message.content
  
      def complete(self, prompt: str, **kwargs) -> str:
          """补全式调用（用于细纲、章节生成）"""
          response = self.client.chat.completions.create(
              model=self.config.model_name,
              messages=[{"role": "user", "content": prompt}],
              temperature=kwargs.get("temperature", self.config.temperature),
              max_tokens=kwargs.get("max_tokens", self.config.max_tokens),
          )
          return response.choices[0].message.content
  ```

  ### 4.2 外部模型配置示例

  ```json
  {
    "name": "本地 Qwen3-32B（vLLM）",
    "provider": "custom",
    "base_url": "http://localhost:8000/v1",
    "api_key": "EMPTY",
    "model_name": "qwen/qwen3-32b",
    "temperature": 0.7,
    "max_tokens": 4096
  }
  ```

  > **注意**：`api_key` 在后端加密存储，所有查询接口均不返回原始密钥。

  ---

  ## 五、关键实现要点

  ### 5.1 Prompt 工程

  - 大纲生成：明确故事类型、篇幅（长篇/短篇）、风格要求
  - 细纲生成：强调章节间的连贯性与节奏控制
  - 事件链生成：突出因果逻辑，避免前后矛盾
  - 角色逻辑链生成：按章节/事件输出每个角色的行为动机与变化（流程A/B自动适配数据源）
  - 角色抽取：结构化输出（JSON），便于解析和存储
  - 章节生成：注入大纲+细纲+角色逻辑链作为上下文
  - 导入反推：针对导入的文本，要求 AI 按原文结构逆向推导大纲与细纲

  ### 5.2 上下文管理

  - 长篇小说上下文可能超出模型窗口，需采用：
    - 摘要压缩（对已完成章节生成摘要）
    - 滑动窗口（保留最近 N 章上下文）
    - 向量检索（将大纲/细纲向量化，按需检索）

  ### 5.3 版本管理实现

  - 大纲/章节每次更新时，先将当前内容存入版本表，再更新主表
  - 版本列表按时间倒序展示，支持差异对比（预留接口）
  - 回滚操作：将指定版本的内容覆盖到主表

  ### 5.4 写作统计实现

  - 前端调用 `start-writing` 时后端记录会话开始时间，返回 `session_id`
  - 用户离开编辑区时调用 `stop-writing` 并传入 `session_id`，后端计算增量并累加
  - 若未正常结束（页面关闭），可通过心跳超时机制自动结算（建议5分钟无心跳视作结束）
  - 字数统计：每次章节保存时重新计算字数并更新总字数

  ### 5.5 导出实现

  - **Word 导出**：使用 python-docx，按章节生成带格式的 Word 文档
  - **TXT 导出**：纯文本拼接，按章节分段
  - **EPUB 导出**：使用 ebooklib，生成标准 EPUB 3.0 格式，支持封面、目录、章节跳转

  ### 5.6 异步任务处理

  长耗时操作（批量生成、导出、AI反推等）应支持异步执行，避免同步 HTTP 超时。实现方式：

  - 后端返回 `202 Accepted` 并携带 `task_id`
  - 客户端轮询 `GET /api/tasks/<task_id>` 获取状态与结果
  - 任务状态机：`pending → running → done/failed`，任务完成后可保留结果数据指针（如导出文件的下载路径）

  ### 5.7 错误处理

  - API 调用失败：重试机制（指数退避）
  - 异步任务失败：任务状态置为 `failed`，记录错误详情
  - 内容审核：可插拔的敏感内容过滤器
  - 用户中断：支持通过取消任务接口中止正在处理的异步任务
  - 导入文件过大：分块处理，避免内存溢出

  ---

  *文档结束 · 优化版 v2.0*